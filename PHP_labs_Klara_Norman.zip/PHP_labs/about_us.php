<!doctype html>
<html>
	<head>
	<meta charset="UTF-8">
	<title>Behind the book</title>
		<link rel="stylesheet" type="text/css" href="CSS/main.css">
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	</head>	
	<body>
		<?php include("header.php"); ?>
		<div id="columnContainer">
			<div id="leftColumn">
				<h2>
					BEHIND BEHIND THE BOOK
				</h2>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae odio porro iure doloremque placeat veritatis tempora quibusdam ullam repellat quod rem maxime fugit enim itaque a numquam similique debitis, eligendi.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae odio porro iure doloremque placeat veritatis tempora quibusdam ullam repellat quod rem maxime fugit enim itaque a numquam similique debitis, eligendi!
					<br>
					<br>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae odio porro iure doloremque placeat veritatis tempora quibusdam ullam repellat quod rem maxime fugit enim itaque a numquam similique debitis, eligendi.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae odio porro iure doloremque placeat veritatis tempora quibusdam ullam repellat quod rem maxime fugit enim itaque a numquam similique debitis, eligendi.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae odio porro iure doloremque placeat veritatis tempora quibusdam ullam repellat quod remmaxime fugit enim itaque a numquam similique debitis, eligendi!
					<br>
					<br>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae odio porro iure doloremque placeat veritatis tempora quibusdam ullam repellat quod rem maxime fugit enim itaque a numquam similique debitis, eligendi!
				</p>
				<figure id="about_us_img">
					<img src="images/about_us.jpg">
				</figure>
			</div>
			<aside id="rightColumn">
				<div id="asideBox">
					<h3>
						Bestsellers
					</h3>
					<ul>
						<li>
							<a href="#">Title 1</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 2</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 3</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 4</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 5</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
					</ul>
				</div>
				<div id="asideBox2">
					<h3>
						New releases
					</h3>
					<ul>
						<li>
							<a href="#">Title 1</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 2</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 3</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 4</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
						<li>
							<a href="#">Title 5</a>
							<p>
								Firstname Lastlastname
							</p>
						</li>
					</ul>
				</div>
			</aside>	
		</div>		
		<?php include("footer.php"); ?>
	</body>
</html>