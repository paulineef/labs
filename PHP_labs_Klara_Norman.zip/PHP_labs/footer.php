<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Behind the book</title>
		<link rel="stylesheet" type="text/css" href="CSS/main.css">
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	</head>
	<body>
		<footer>
			<div id="footerPart2">
				<p>
					Discover, share and reserve books through an adventure behind the books.
				</p>
				<p id="footerP2">
					&#169;Behind the book - All rights reserved - 2017
				</p>
			</div>
		</footer>
	</body>
</html>