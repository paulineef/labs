<?php include ('header.php'); ?>
<body>
	<img class="topimg" src="img/index.png"/>
	<div class="content">
		<div class="half">
			<h3>About us</h3>
			
			<p>
				Ei eum dicam urbanitas moderatius, at eam ferri dissentiunt. Sea no atqui dolorem, per cu nisl quaestio. Et vel semper lucilius, choro dolore animal his ut. Sed ad dolorum facilisis interpretaris, usu volumus petentium no, at graece vivendum appellantur eos. In dolorem mediocrem has, eam cu cibo elitr labitur. Clita copiosae ponderum sed te, ea nec justo legere volutpat.
			</p>
			<h4>And so we became something</h4>
			<p>
				Utroque qualisque delicatissimi sea cu, ut falli dicunt epicurei usu. Duo ea congue audire, mazim alterum singulis mei in. Duo ei nullam labore. Vel et alterum epicuri comprehensam. Qui summo inciderint in, sed odio dicam mnesarchum eu.
			</p>
			<h4>If you have any questions, please <a href="contact.php">contact</a> us!</h4>
		</div>
	</div>
</body>

<?php include ('footer.php'); ?>