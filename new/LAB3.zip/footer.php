	<footer>
			Pauline Fagerberg 2017
			<a href="admin.php">Admin?</a>
	</footer>
</body>
</html>